<form <?php echo e($attributes->class('space-y-6 filament-form')); ?>>
    <?php echo e($slot); ?>

</form>
<?php /**PATH /home/u240766717/domains/hr.ebdaa-alqrosh.com/public_html/vendor/filament/filament/src/../resources/views/components/form/index.blade.php ENDPATH**/ ?>