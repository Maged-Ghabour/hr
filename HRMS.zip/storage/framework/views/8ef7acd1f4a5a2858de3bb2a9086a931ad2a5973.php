<div class="flex flex-row gap-4">
    <img src="<?php echo e(asset('favicon.png')); ?>" alt="Logo" class="h-16">
    
</div><?php /**PATH /home/u240766717/domains/hr.ebdaa-alqrosh.com/public_html/resources/views/vendor/filament/components/brand.blade.php ENDPATH**/ ?>