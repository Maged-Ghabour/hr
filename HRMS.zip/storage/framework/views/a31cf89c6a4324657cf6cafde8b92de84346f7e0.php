<h2 <?php echo e($attributes->class(['text-xl font-bold tracking-tight filament-tables-header-heading'])); ?>>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH D:\HRMS\vendor\filament\tables\src\/../resources/views/components/header/heading.blade.php ENDPATH**/ ?>