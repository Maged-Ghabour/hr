<?php foreach($attributes->onlyProps([
    'recordUrl' => null,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'recordUrl' => null,
]); ?>
<?php foreach (array_filter(([
    'recordUrl' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<tr
    <?php echo e($attributes->class([
            'hover:bg-primary-500/5 dark:hover:bg-primary-500/5' => $recordUrl,
            'filament-tables-row',
        ])); ?>

>
    <?php echo e($slot); ?>

</tr>
<?php /**PATH /home/u240766717/domains/hr.ebdaa-alqrosh.com/public_html/vendor/filament/tables/src/../resources/views/components/row.blade.php ENDPATH**/ ?>