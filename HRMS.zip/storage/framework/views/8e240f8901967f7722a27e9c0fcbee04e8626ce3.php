<?php foreach($attributes->onlyProps([
    'allRecordsCount',
    'colspan',
    'selectedRecordsCount',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'allRecordsCount',
    'colspan',
    'selectedRecordsCount',
]); ?>
<?php foreach (array_filter(([
    'allRecordsCount',
    'colspan',
    'selectedRecordsCount',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<tr x-cloak <?php echo e($attributes->class(['bg-primary-500/10 filament-tables-selection-indicator'])); ?>>
    <td class="px-4 py-2 whitespace-nowrap text-sm" colspan="<?php echo e($colspan); ?>">
        <div>
            <span x-show="isLoading">
                <svg class="inline-block animate-spin w-4 h-4 mr-3 text-primary-600" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M2 12C2 6.47715 6.47715 2 12 2V5C8.13401 5 5 8.13401 5 12H2Z" />
                </svg>
            </span>

            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dark:text-white' => config('tables.dark_mode')]) ?>" x-text="
                singularText = '<?php echo e(trans_choice('tables::table.selection_indicator.selected_count', 1, ['count' => 1])); ?>'
                pluralText = '<?php echo e(trans_choice('tables::table.selection_indicator.selected_count', 2, ['count' => 2])); ?>'

                return (selectedRecords.length === 1) ?
                    singularText.replace('1', selectedRecords.length) :
                    pluralText.replace('2', selectedRecords.length)
            "></span>

            <span x-show="<?php echo e($allRecordsCount); ?> !== selectedRecords.length">
                <button x-on:click="selectAllRecords" class="text-primary-600 text-sm font-medium">
                    <?php echo e(__('tables::table.selection_indicator.buttons.select_all.label', ['count' => $allRecordsCount])); ?>.
                </button>
            </span>

            <span>
                <button x-on:click="deselectAllRecords" class="text-primary-600 text-sm font-medium">
                    <?php echo e(__('tables::table.selection_indicator.buttons.deselect_all.label')); ?>.
                </button>
            </span>
        </div>
    </td>
</tr>
<?php /**PATH /home/u240766717/domains/hr.ebdaa-alqrosh.com/public_html/vendor/filament/tables/src/../resources/views/components/selection-indicator.blade.php ENDPATH**/ ?>