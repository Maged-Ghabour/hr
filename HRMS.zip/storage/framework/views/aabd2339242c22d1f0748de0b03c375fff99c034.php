<div <?php echo e($attributes->class([
    'text-sm text-gray-600 filament-forms-field-wrapper-helper-text',
    'dark:text-gray-300' => config('forms.dark_mode'),
])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/u240766717/domains/hr.ebdaa-alqrosh.com/public_html/vendor/filament/forms/src/../resources/views/components/field-wrapper/helper-text.blade.php ENDPATH**/ ?>