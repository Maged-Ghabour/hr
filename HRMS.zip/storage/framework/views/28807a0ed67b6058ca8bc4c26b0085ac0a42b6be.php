<p <?php echo e($attributes->class(['text-sm text-danger-600 filament-forms-field-wrapper-error-message '])); ?>>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /home/u240766717/domains/hr.ebdaa-alqrosh.com/public_html/vendor/filament/forms/src/../resources/views/components/field-wrapper/error-message.blade.php ENDPATH**/ ?>