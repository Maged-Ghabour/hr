<div aria-hidden="true" <?php echo e($attributes->class([
    'border-t filament-hr',
    'dark:border-gray-700' => config('filament.dark_mode'),
])); ?>></div>
<?php /**PATH /home/u240766717/domains/hr.ebdaa-alqrosh.com/public_html/vendor/filament/filament/src/../resources/views/components/hr.blade.php ENDPATH**/ ?>