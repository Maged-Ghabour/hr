<p <?php echo e($attributes->class([
    'text-sm font-medium text-gray-500 filament-tables-empty-state-description',
    'dark:text-gray-400' => config('tables.dark_mode'),
])); ?>>
    <?php echo e($slot); ?>

</p>
<?php /**PATH D:\HRMS\vendor\filament\tables\src\/../resources/views/components/empty-state/description.blade.php ENDPATH**/ ?>