<h3 <?php echo e($attributes->class(['text-gray-500 filament-modal-subheading'])); ?>>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH /home/u240766717/domains/hr.ebdaa-alqrosh.com/public_html/vendor/filament/filament/src/../resources/views/components/modal/subheading.blade.php ENDPATH**/ ?>