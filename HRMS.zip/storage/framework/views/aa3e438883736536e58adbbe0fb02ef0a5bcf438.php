<div aria-hidden="true" <?php echo e($attributes->class([
    'border-t filament-hr',
    'dark:border-gray-700' => config('filament.dark_mode'),
])); ?>></div>
<?php /**PATH D:\HRMS\vendor\filament\filament\src\/../resources/views/components/hr.blade.php ENDPATH**/ ?>