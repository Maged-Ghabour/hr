<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'filament::components.page','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form wire:submit.prevent="submit">
        <?php echo e($this->form); ?>

        <br/>
        <button type="submit" class="inline-flex
        items-center justify-center font-medium tracking-tight space-y-2 rounded-lg border
        transition-colors focus:outline-none focus:ring-offset-2 focus:ring-2 focus:ring-inset
        filament-button dark:focus:ring-offset-0 h-9 px-4 text-white shadow focus:ring-white
        border-transparent bg-primary-600 hover:bg-primary-500 focus:bg-primary-700
        focus:ring-offset-primary-700 filament-page-button-action"
        wire:loading.attr="disabled"
        wire:loading.class="opacity-70 cursor-wait"
        >
            save
        </button>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home/u240766717/domains/hr.ebdaa-alqrosh.com/public_html/resources/views/filament/pages/settings.blade.php ENDPATH**/ ?>