<div <?php echo e($attributes->class([
    'px-6 py-4 filament-global-search-no-results-message',
    'dark:text-gray-200' => config('filament.dark_mode'),
])); ?>>
    <?php echo e(__('filament::global-search.no_results_message')); ?>

</div>
<?php /**PATH D:\HRMS\vendor\filament\filament\src\/../resources/views/components/global-search/no-results-message.blade.php ENDPATH**/ ?>