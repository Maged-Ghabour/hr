<div class="filament-resources-has-many-relation-manager">
    <?php echo e($this->table); ?>

</div>
<?php /**PATH D:\HRMS\vendor\filament\filament\src\/../resources/views/resources/relation-managers/has-many-relation-manager.blade.php ENDPATH**/ ?>