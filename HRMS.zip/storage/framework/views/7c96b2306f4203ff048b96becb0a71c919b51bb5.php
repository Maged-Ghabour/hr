<svg class="h-5 w-5 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
  <path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/>
</svg><?php /**PATH D:\HRMS\storage\framework\views/3281e3ea9e7ebfb850b782a62324441f144208a7.blade.php ENDPATH**/ ?>