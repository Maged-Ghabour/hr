<div
    aria-labelledby="<?php echo e($getId()); ?>"
    id="<?php echo e($getId()); ?>"
    role="tabpanel"
    tabindex="0"
    x-bind:class="{ 'invisible h-0 p-0 overflow-y-hidden': tab !== '<?php echo e($getId()); ?>' }"
    <?php echo e($attributes->merge($getExtraAttributes())->class(['p-6 focus:outline-none filament-forms-tabs-component-tab'])); ?>

>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH /home/u240766717/domains/hr.ebdaa-alqrosh.com/public_html/vendor/filament/forms/src/../resources/views/components/tabs/tab.blade.php ENDPATH**/ ?>