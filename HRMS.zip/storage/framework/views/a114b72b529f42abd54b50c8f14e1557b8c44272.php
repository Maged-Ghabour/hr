<div
    x-data="{ tab: '<?php echo e(count($getTabsConfig()) ? array_key_first($getTabsConfig()) : null); ?>', tabs: <?php echo e(json_encode($getTabsConfig())); ?> }"
    x-on:expand-concealing-component.window="if ($event.detail.id in tabs) tab = $event.detail.id"
    x-cloak
    <?php echo $getId() ? "id=\"{$getId()}\"" : null; ?>

    <?php echo e($attributes->merge($getExtraAttributes())->class([
        'rounded-xl shadow-sm border border-gray-300 bg-white filament-forms-tabs-component',
        'dark:bg-gray-700 dark:border-gray-600' => config('forms.dark_mode'),
    ])); ?>

    <?php echo e($getExtraAlpineAttributeBag()); ?>

>
    <div
        <?php echo $getLabel() ? 'aria-label="' . $getLabel() . '"' : null; ?>

        role="tablist"
        class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            'rounded-t-xl flex overflow-y-auto bg-gray-100',
            'dark:bg-gray-800' => config('forms.dark_mode'),
        ]) ?>"
    >
        <?php $__currentLoopData = $getTabsConfig(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabId => $tabLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button
                type="button"
                aria-controls="<?php echo e($tabId); ?>"
                x-bind:aria-selected="tab === '<?php echo e($tabId); ?>'"
                x-on:click="tab = '<?php echo e($tabId); ?>'"
                role="tab"
                x-bind:tabindex="tab === '<?php echo e($tabId); ?>' ? 0 : -1"
                class="shrink-0 p-3 text-sm font-medium"
                x-bind:class="{ 'bg-white <?php if(config('forms.dark_mode')): ?> dark:bg-gray-700 <?php endif; ?>': tab === '<?php echo e($tabId); ?>' }"
            >
                <?php echo e($tabLabel); ?>

            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php $__currentLoopData = $getChildComponentContainer()->getComponents(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($tab); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/u240766717/domains/hr.ebdaa-alqrosh.com/public_html/vendor/filament/forms/src/../resources/views/components/tabs.blade.php ENDPATH**/ ?>