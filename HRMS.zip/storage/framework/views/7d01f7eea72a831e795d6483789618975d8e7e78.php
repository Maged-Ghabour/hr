<h2 <?php echo e($attributes->class(['text-xl font-bold tracking-tight filament-modal-heading'])); ?>>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH D:\HRMS\vendor\filament\filament\src\/../resources/views/components/modal/heading.blade.php ENDPATH**/ ?>