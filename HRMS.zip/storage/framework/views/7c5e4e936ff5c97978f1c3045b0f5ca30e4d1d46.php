<h3 <?php echo e($attributes->class(['text-gray-500 filament-modal-subheading'])); ?>>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH D:\HRMS\vendor\filament\filament\src\/../resources/views/components/modal/subheading.blade.php ENDPATH**/ ?>