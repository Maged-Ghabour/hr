<p <?php echo e($attributes->class(['text-gray-900 filament-tables-header-description'])); ?>>
    <?php echo e($slot); ?>

</p>
<?php /**PATH D:\HRMS\vendor\filament\tables\src\/../resources/views/components/header/description.blade.php ENDPATH**/ ?>