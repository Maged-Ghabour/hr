<table width="100%">
    <tr>
        <td rowspan="4"><img src="{{ public_path('favicon.png') }}" alt="Logo" width="120" height="120"></td>
        <td style="text-align: center;padding: 4px; font-weight: bold;">إبداع القروش</td>
    </tr>
    <tr>
        <td style="text-align: center;padding: 4px; font-weight: bold;">Website:mrdiscount.com, Email:
            hello@mrdiscount.com, Mobile: 0782 150 150.</td>
    </tr>
    <tr>
        <td style="text-align: center;padding: 4px; font-weight: bold;">HUMAN RESOURCE DEPARTMENT</td>
    </tr>
    <tr>
        <td style="text-align: center;padding: 4px;font-weight: bold;">PAYSLIP FOR THE PERIOD OF
            {{strtoupper($data->month)}} {{$data->year}}</td>
    </tr>
</table>